## Version 1.0.0 (4 aug 2019)
- Initial template
- Bootstrap version 3.3.7

## Version 1.1.0 (4 Jan 2021)
- Instagram Feed carousel added
- Slick slider added